#ifndef PROCESSUS_H_INCLUDED
#define PROCESSUS_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>

/*** Définition d'une liste de processus ***/

typedef struct elemThread{
    int tempsExec;
    pthread_t pthread;
    struct elemThread *suivant;
}elementThread;

typedef elementThread *listeThread;

/*** Définition d'une liste de liste de processus ***/

typedef struct elem{
    int priorite;
    listeThread liste;
    struct elem *suivant;
}element;

typedef element *Liste;

/*** Opérations sur les listes de processus ***/

void ajouterThread(Liste listeDeListe);

/*** Opérations sur une liste de listes de processus ***/

Liste creerListe(Liste liste);
Liste ajouterListeThread(int p, Liste liste);

#endif // PROCESSUS_H_INCLUDED
