#include "processus.h"

void *fonctionThread(void *arg){
    pthread_exit(NULL);
}

/*** Fonction sur les listes de thread ***/

/* Fonction qui créer un thread avec une priorité et un temps d'éxécution different et l'ajoute à une liste
de thread en fonction de sa priorité */

void ajouterThread(Liste listeDeListe){
    pthread_t thread;
    int priorite;
    int tempsExec;


    priorite=rand()%11;//Creer une priorité aléatoire compris entre 0 et 10
    tempsExec=rand()%20+1;//Creer un temps d'éxécution compris entre 1 et 20

    Liste i=listeDeListe;

    while(i->priorite!=priorite){
        i=i->suivant;
    }
    listeThread j=i->liste;
    while(j->suivant!=NULL){
        j=j->suivant;
    }
    j->suivant=malloc(sizeof(elementThread));
    j->pthread=thread;
    j->tempsExec=tempsExec;

    pthread_create(&thread, NULL, fonctionThread, NULL);
    printf("Ajout d'un thread de priorité: %d et de temps d'éxécution %d\n",priorite,tempsExec);
}

/*** Fonction sur les listes de listes de thread ***/

//Fonction qui initialise la liste de liste de thread avec 11 listes de priorité entre 0 et 10

Liste creerListe(Liste liste){
    liste=malloc(sizeof(element));
    for(int i=0;i<=10;i++){
        liste=ajouterListeThread(i,liste);
    }

    printf("Création d'une liste de liste de thread\n");
    return liste;
}

//Fonction qui ajoute une liste de thread à une liste de liste de thread

Liste ajouterListeThread(int p, Liste liste){
    Liste i=liste;

    while(i->suivant!=NULL){
        i=i->suivant;
    }

    i->suivant=malloc(sizeof(element));
    i->priorite=p;
    i->liste=malloc(sizeof(elementThread));

    return liste;
}
