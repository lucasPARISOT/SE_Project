#include "processus.h"

int main(){
    Liste liste;
    liste=creerListe(liste);
    srand(time(NULL));
    ajouterThread(liste);
    ajouterThread(liste);
    ajouterThread(liste);
    ajouterThread(liste);
    return 0;
}
